var arrNumbers = [10, 11, 12, 13, 14, 15, 16];
var tableData = [
  { Dates: "Mon Dec 17 2018", Venue: "Ronald Lane", Location: "San Francisco, CA" },
  { Dates: "Mon Dec 17 2018", Venue: "Pier 3 East", Location: "San Francisco, CA" },
  { Dates: "Mon Dec 17 2018", Venue: "View Loungue", Location: "San Francisco, CA" },
  { Dates: "Mon Dec 17 2018", Venue: "Hyatt Agency", Location: "San Francisco, CA" },
  { Dates: "Mon Dec 17 2018", Venue: "Moscow Center", Location: "San Francisco, CA" },
  { Dates: "Mon Dec 17 2018", Venue: "Pres Club", Location: "San Francisco, CA" }, 
];

for (var obj of tableData) {
  console.log(obj);
}